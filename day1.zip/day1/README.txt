what is diffrence between h1 to h6 tag also find font size?
how to generate number from 1 to 100 in list?
w3.org is wesite is used to learn all html and css .
they have designed all html css tags and attribute.
div :- it is used for design the structure.

how to open a html file in new tab ? :- target attr it is used to open a html file in new tab.

